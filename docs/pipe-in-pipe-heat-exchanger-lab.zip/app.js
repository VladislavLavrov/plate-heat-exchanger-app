/*
  Виртуальная лабораторная: теплообменник «труба в трубе»
  - Модель: эффективность–NTU для прямотока и противотока
  - «Измерения»: добавляем шум к температурам (термопары)
  - Далее считаем Q, Δt_lm и k = Qх/(F·Δt_lm) как в методичке.
*/

(function(){
  // ----- Константы установки (из методических указаний)
  const d = 0.0127;   // м (наружный диаметр внутренней трубы)
  const L = 0.37;     // м (длина рабочего участка)
  const F = Math.PI * d * L; // площадь теплообмена
  const LAB_TITLE = "Испытание теплообменника конструкции «труба в трубе»";

  // Табличные значения cp воды (Дж/(кг·К)) в зависимости от T, °C
  // 0..100°C, как в практикуме
  const cpTable = [
    {t:0,   cp:4218},
    {t:10,  cp:4192},
    {t:20,  cp:4182},
    {t:40,  cp:4178},
    {t:60,  cp:4184},
    {t:80,  cp:4196},
    {t:100, cp:4216},
  ];

  function lerp(a,b,x){ return a + (b-a)*x; }

  function cpWater(tC){
    if (tC <= cpTable[0].t) return cpTable[0].cp;
    if (tC >= cpTable[cpTable.length-1].t) return cpTable[cpTable.length-1].cp;
    for (let i=0;i<cpTable.length-1;i++){
      const p1=cpTable[i], p2=cpTable[i+1];
      if (tC>=p1.t && tC<=p2.t){
        const x = (tC-p1.t)/(p2.t-p1.t);
        return lerp(p1.cp,p2.cp,x);
      }
    }
    return 4180;
  }

  // Псевдослучайный генератор для воспроизводимости
  function mulberry32(seed){
    let a = seed >>> 0;
    return function(){
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function randUniform(rng, min, max){ return min + (max-min)*rng(); }

  // Эффективность ε(NTU, Cr) для прямотока/противотока
  function epsParallel(NTU, Cr){
    const denom = (1 + Cr);
    return (1 - Math.exp(-NTU * denom)) / denom;
  }
  function epsCounter(NTU, Cr){
    if (Math.abs(Cr - 1) < 1e-9){
      return NTU / (1 + NTU);
    }
    const a = 1 - Cr;
    return (1 - Math.exp(-NTU * a)) / (1 - Cr * Math.exp(-NTU * a));
  }

  function clamp(x, lo, hi){ return Math.max(lo, Math.min(hi, x)); }

  function lmtD_parallel(ThIn, ThOut, TcIn, TcOut){
    const dt1 = ThIn - TcIn;
    const dt2 = ThOut - TcOut;
    return lmtd(dt1, dt2);
  }
  function lmtD_counter(ThIn, ThOut, TcIn, TcOut){
    const dt1 = ThIn - TcOut;
    const dt2 = ThOut - TcIn;
    return lmtd(dt1, dt2);
  }
  function lmtd(dt1, dt2){
    const a = dt1, b = dt2;
    if (Math.abs(a - b) < 1e-6) return (a + b) / 2;
    const aa = Math.max(a, 1e-6);
    const bb = Math.max(b, 1e-6);
    return (aa - bb) / Math.log(aa / bb);
  }

  const $ = (id)=>document.getElementById(id);

  const ui = {
    btnCounter: $("btnCounter"),
    btnParallel: $("btnParallel"),
    modePill: $("modePill"),

    ThIn: $("ThIn"),
    TcIn: $("TcIn"),
    Gh: $("Gh"),
    Gc: $("Gc"),
    U: $("U"),
    noise: $("noise"),
    seed: $("seed"),

    ThInVal: $("ThInVal"),
    TcInVal: $("TcInVal"),
    GhVal: $("GhVal"),
    GcVal: $("GcVal"),
    UVal: $("UVal"),
    noiseVal: $("noiseVal"),

    btnNewRun: $("btnNewRun"),
    btnReset: $("btnReset"),
    btnAddToJournal: $("btnAddToJournal"),
    btnClearJournal: $("btnClearJournal"),
    btnExportExcel: $("btnExportExcel"),

    ThOut: $("ThOut"),
    TcOut: $("TcOut"),
    Qcold: $("Qcold"),
    Qhot: $("Qhot"),
    eps: $("eps"),
    LMTD: $("LMTD"),
    Area: $("Area"),
    kCalc: $("kCalc"),
    logTable: $("logTable"),
    journalTable: $("journalTable"),
    analyticsText: $("analyticsText"),

    effChart: $("effChart"),
    tempProfileChart: $("tempProfileChart"),
  };

  let mode = "counter";
  let rng = mulberry32(12345);
  let lastInputs = null;
  let lastResult = null;
  let journal = [];

  function getInputs(){
    return {
      ThIn: parseFloat(ui.ThIn.value),
      TcIn: parseFloat(ui.TcIn.value),
      Gh: parseFloat(ui.Gh.value),
      Gc: parseFloat(ui.Gc.value),
      U: parseFloat(ui.U.value),
      noise: parseFloat(ui.noise.value),
      seed: parseInt(ui.seed.value || "0", 10),
    };
  }

  function format(x, digits=2){ return Number(x).toFixed(digits); }
  function formatW(x){ return `${format(x,0)}`; }
  function modeLabel(m){ return m === "counter" ? "противоток" : "прямоток"; }

  function setMode(newMode){
    mode = newMode;
    const isCounter = mode === "counter";
    ui.btnCounter.setAttribute("aria-pressed", isCounter ? "true" : "false");
    ui.btnParallel.setAttribute("aria-pressed", !isCounter ? "true" : "false");
    ui.modePill.textContent = `Режим: ${modeLabel(mode)}`;
    recalc();
  }

  function simulateOnce({ThIn, TcIn, Gh, Gc, U, noise, seed}){
    rng = mulberry32(seed);

    const mHot = Gh / 60.0;
    const mCold = Gc / 60.0;

    const cpHot = cpWater(ThIn);
    const cpCold = cpWater(TcIn);

    const Ch = mHot * cpHot;
    const Cc = mCold * cpCold;

    const Cmin = Math.min(Ch, Cc);
    const Cmax = Math.max(Ch, Cc);
    const Cr = Cmin / Cmax;

    const UA = U * F;
    const NTU = UA / Math.max(Cmin, 1e-9);

    const eps = mode === "counter" ? epsCounter(NTU, Cr) : epsParallel(NTU, Cr);
    const Qmax = Cmin * (ThIn - TcIn);
    const Q = clamp(eps * Qmax, 0, Qmax);

    const ThOut_true = ThIn - Q / Math.max(Ch, 1e-9);
    const TcOut_true = TcIn + Q / Math.max(Cc, 1e-9);

    const ThIn_m  = ThIn  + randUniform(rng, -noise, noise);
    const ThOut_m = ThOut_true + randUniform(rng, -noise, noise);
    const TcIn_m  = TcIn  + randUniform(rng, -noise, noise);
    const TcOut_m = TcOut_true + randUniform(rng, -noise, noise);

    const cpH_m = cpWater((ThIn_m + ThOut_m)/2);
    const cpC_m = cpWater((TcIn_m + TcOut_m)/2);

    const Qhot = mHot * cpH_m * (ThIn_m - ThOut_m);
    const Qcold = mCold * cpC_m * (TcOut_m - TcIn_m);

    const LMTD = mode === "counter"
      ? lmtD_counter(ThIn_m, ThOut_m, TcIn_m, TcOut_m)
      : lmtD_parallel(ThIn_m, ThOut_m, TcIn_m, TcOut_m);

    const kCalc = Qcold / (F * Math.max(LMTD, 1e-9));

    return {
      mHot, mCold, cpHot, cpCold, Ch, Cc, Cmin, Cmax, Cr, UA, NTU,
      eps, Q, Qmax,
      ThOut_true, TcOut_true,
      meas: {ThIn_m, ThOut_m, TcIn_m, TcOut_m},
      Qhot, Qcold, LMTD, kCalc,
    };
  }

  let chart;
  let tempChart;

  function buildChart(){
    const ctx = ui.effChart.getContext("2d");
    chart = new Chart(ctx, {
      type: "line",
      data: {
        labels: [],
        datasets: [
          { label: "Прямоток (ε)", data: [], borderWidth: 2, tension: 0.25, pointRadius: 0 },
          { label: "Противоток (ε)", data: [], borderWidth: 2, tension: 0.25, pointRadius: 0 },
          { label: "Текущая точка", data: [], borderWidth: 0, pointRadius: 5, pointHoverRadius: 6, showLine: false }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: "#cfe1ff" } },
          tooltip: { callbacks: { label: (ctx)=> `${ctx.dataset.label}: ${ctx.parsed.y.toFixed(3)}` }}
        },
        scales: {
          x: { title: { display:true, text:"Расход горячего, л/мин", color:"#cfe1ff" }, ticks:{ color:"#a6b3c7" }, grid:{ color:"rgba(255,255,255,.06)" } },
          y: { title: { display:true, text:"Эффективность ε", color:"#cfe1ff" }, min:0, max:1, ticks:{ color:"#a6b3c7" }, grid:{ color:"rgba(255,255,255,.06)" } }
        }
      }
    });
  }


  function buildTempProfileChart(){
    const ctx = ui.tempProfileChart.getContext("2d");
    tempChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: ["Вход", "Выход"],
        datasets: [
          { label: "Горячий", data: [0,0], borderColor: "#60a5fa", backgroundColor: "rgba(96,165,250,.2)", borderWidth: 2, pointRadius: 3, tension: 0.2 },
          { label: "Холодный", data: [0,0], borderColor: "#fb7185", backgroundColor: "rgba(251,113,133,.2)", borderWidth: 2, pointRadius: 3, tension: 0.2 },
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: "#cfe1ff" } } },
        scales: {
          x: { ticks: { color: "#a6b3c7" }, grid: { color:"rgba(255,255,255,.06)" } },
          y: { title:{ display:true, text:"Температура, °C", color:"#cfe1ff" }, ticks: { color: "#a6b3c7" }, grid: { color:"rgba(255,255,255,.06)" } }
        }
      }
    });
  }

  function updateTempProfileChart(res){
    if (!tempChart) return;
    tempChart.data.datasets[0].data = [res.meas.ThIn_m, res.meas.ThOut_m];
    tempChart.data.datasets[1].data = [res.meas.TcIn_m, res.meas.TcOut_m];
    tempChart.update();
  }

  function updateChart(inputs){
    const GhMin = parseFloat(ui.Gh.min);
    const GhMax = parseFloat(ui.Gh.max);
    const step = 0.25;

    const labels = [];
    const epsPar = [];
    const epsCnt = [];

    for (let g = GhMin; g <= GhMax + 1e-9; g += step){
      labels.push(g.toFixed(2));
      const local = { ...inputs, Gh: g };
      const noNoise = { ...local, noise: 0.0, seed: 1 };

      const oldMode = mode;
      mode = "parallel";
      epsPar.push(simulateOnce(noNoise).eps);
      mode = "counter";
      epsCnt.push(simulateOnce(noNoise).eps);
      mode = oldMode;
    }

    const currentG = inputs.Gh;
    const oldMode = mode;
    mode = "parallel";
    const epHerePar = simulateOnce({ ...inputs, noise: 0.0, seed: 2 }).eps;
    mode = "counter";
    const epHereCnt = simulateOnce({ ...inputs, noise: 0.0, seed: 2 }).eps;
    mode = oldMode;

    const epHere = (mode === "counter") ? epHereCnt : epHerePar;

    chart.data.labels = labels;
    chart.data.datasets[0].data = epsPar;
    chart.data.datasets[1].data = epsCnt;
    chart.data.datasets[2].data = [{ x: currentG.toFixed(2), y: epHere }];
    chart.update();
  }

  function fillCurrentTable(res, inputs){
    const rows = [
      ["Схема движения", modeLabel(mode), ""],
      ["Температура горячего на входе", "T₁′", `${format(res.meas.ThIn_m,2)} °C`],
      ["Температура горячего на выходе", "T₁″", `${format(res.meas.ThOut_m,2)} °C`],
      ["Температура холодного на входе", "T₂′", `${format(res.meas.TcIn_m,2)} °C`],
      ["Температура холодного на выходе", "T₂″", `${format(res.meas.TcOut_m,2)} °C`],
      ["Расход горячего", "Vг", `${format(inputs.Gh,2)} л/мин  (~${format(res.mHot,4)} кг/с)`],
      ["Расход холодного", "Vх", `${format(inputs.Gc,2)} л/мин  (~${format(res.mCold,4)} кг/с)`],
      ["Q по горячему", "Qг", `${formatW(res.Qhot)} Вт`],
      ["Q по холодному", "Qх", `${formatW(res.Qcold)} Вт`],
      ["Температурный напор", "Δt_lm", `${format(res.LMTD,2)} °C`],
      ["Площадь теплообмена", "F", `${format(F,5)} м²`],
      ["Коэффициент теплопередачи", "k", `${format(res.kCalc,0)} Вт/(м²·К)`],
    ];

    ui.logTable.innerHTML = rows.map((r) => `
      <tr>
        <td>${r[0]}</td>
        <td class="mono">${r[1]}</td>
        <td class="mono">${r[2]}</td>
      </tr>`).join("");
  }

  function renderJournal(){
    if (!journal.length){
      ui.journalTable.innerHTML = `<tr><td colspan="10" class="mono">Журнал пуст. Добавьте первый опыт.</td></tr>`;
      return;
    }

    ui.journalTable.innerHTML = journal.map((e, idx) => `
      <tr>
        <td>${idx + 1}</td>
        <td class="mono">${e.time}</td>
        <td>${modeLabel(e.mode)}</td>
        <td class="mono">${format(e.inputs.ThIn,1)}</td>
        <td class="mono">${format(e.inputs.TcIn,1)}</td>
        <td class="mono">${format(e.inputs.Gh,2)}</td>
        <td class="mono">${format(e.inputs.Gc,2)}</td>
        <td class="mono">${format(e.result.eps,3)}</td>
        <td class="mono">${formatW(e.result.Qcold)}</td>
        <td class="mono">${format(e.result.kCalc,0)}</td>
      </tr>
    `).join("");
  }

  function buildAnalytics(res){
    const imbalance = Math.abs(res.Qhot - res.Qcold) / Math.max(Math.abs(res.Qhot), 1e-6) * 100;

    const efficiencyMark = res.eps >= 0.65
      ? "высокая"
      : res.eps >= 0.45
      ? "удовлетворительная"
      : "пониженная";

    const qualityMark = imbalance <= 8
      ? "тепловой баланс согласован"
      : imbalance <= 15
      ? "имеется умеренная несогласованность теплового баланса"
      : "наблюдается существенное расхождение теплового баланса";

    const recommendationFlow = mode === "counter"
      ? "Сохраняйте противоточное движение как предпочтительный режим для максимизации среднего температурного напора."
      : "Рекомендуется провести дополнительный расчет в режиме противотока и сравнить прирост ε при тех же расходах.";

    ui.analyticsText.innerHTML = `
      <p><strong>Научно-техническая интерпретация:</strong> в текущем опыте эффективность теплообменника ε = <span class="mono">${format(res.eps,3)}</span>, что соответствует уровню «<strong>${efficiencyMark}</strong>» для учебной установки типа «труба в трубе».</p>
      <p><strong>Диагностика баланса:</strong> Qг = <span class="mono">${formatW(res.Qhot)} Вт</span>, Qх = <span class="mono">${formatW(res.Qcold)} Вт</span>; относительное расхождение составляет <span class="mono">${format(imbalance,1)}%</span>, следовательно, <strong>${qualityMark}</strong>.</p>
      <p><strong>Оценка теплопередачи:</strong> расчетный коэффициент <span class="mono">kрасч = ${format(res.kCalc,0)} Вт/(м²·К)</span>, логарифмический температурный напор <span class="mono">Δt<sub>lm</sub> = ${format(res.LMTD,2)} °C</span>. Эти параметры подтверждают физическую правдоподобность режима теплообмена.</p>
      <p><strong>Рекомендации инженера-теплотехника:</strong></p>
      <ul>
        <li>${recommendationFlow}</li>
        <li>Для повышения надежности выводов выполните серию опытов при ступенчатом изменении расхода горячего и холодного контуров, фиксируя журнал экспериментов.</li>
        <li>При росте шумов измерений снижайте шаг изменения параметров и усредняйте не менее 3 запусков для каждого режима.</li>
      </ul>
    `;
  }

  function recalc(){
    const inputs = getInputs();

    ui.ThInVal.textContent = `${format(inputs.ThIn,1)} °C`;
    ui.TcInVal.textContent = `${format(inputs.TcIn,1)} °C`;
    ui.GhVal.textContent = `${format(inputs.Gh,2)} л/мин`;
    ui.GcVal.textContent = `${format(inputs.Gc,2)} л/мин`;
    ui.UVal.textContent = `${format(inputs.U,0)} Вт/(м²·К)`;
    ui.noiseVal.textContent = `${format(inputs.noise,2)} °C`;

    if (inputs.ThIn <= inputs.TcIn + 0.1){
      ui.ThIn.value = String(inputs.TcIn + 5);
    }

    const normalizedInputs = getInputs();
    const res = simulateOnce(normalizedInputs);

    lastInputs = { ...normalizedInputs };
    lastResult = { ...res };

    ui.ThOut.textContent = `${format(res.meas.ThOut_m,2)} °C`;
    ui.TcOut.textContent = `${format(res.meas.TcOut_m,2)} °C`;
    ui.Qcold.textContent = formatW(res.Qcold);
    ui.Qhot.textContent = formatW(res.Qhot);
    ui.eps.textContent = `${format(res.eps,3)}`;
    ui.LMTD.textContent = `${format(res.LMTD,2)}`;
    ui.Area.textContent = `${format(F,5)}`;
    ui.kCalc.textContent = `${format(res.kCalc,0)}`;

    fillCurrentTable(res, normalizedInputs);
    updateChart(normalizedInputs);
    updateTempProfileChart(res);
    buildAnalytics(res);

    console.assert(F > 0, "Area F must be positive");
    console.assert(res.eps >= -1e-6 && res.eps <= 1+1e-6, "eps must be within [0,1]");
  }

  function addCurrentToJournal(){
    if (!lastInputs || !lastResult) return;

    const now = new Date();
    const time = now.toLocaleString("ru-RU", { hour12: false });

    journal.unshift({
      time,
      mode,
      inputs: { ...lastInputs },
      result: {
        eps: lastResult.eps,
        Qcold: lastResult.Qcold,
        kCalc: lastResult.kCalc,
      },
    });

    if (journal.length > 50){
      journal = journal.slice(0, 50);
    }

    renderJournal();
  }


  function clearJournal(){
    journal = [];
    renderJournal();
  }

  function exportExcel(){
    if (!lastInputs || !lastResult){
      alert("Нет данных для экспорта. Выполните расчет опыта.");
      return;
    }

    const escapeCsv = (value) => `"${String(value).replace(/"/g, '""')}"`;
    const rows = [
      ["Лабораторная работа", LAB_TITLE],
      ["Дата", new Date().toLocaleString("ru-RU", { hour12: false })],
      ["Режим", modeLabel(mode)],
      [],
      ["Исходные данные"],
      ["T1' (°C)", format(lastInputs.ThIn,1)],
      ["T2' (°C)", format(lastInputs.TcIn,1)],
      ["Gг (л/мин)", format(lastInputs.Gh,2)],
      ["Gх (л/мин)", format(lastInputs.Gc,2)],
      ["k истинный (Вт/(м²·К))", format(lastInputs.U,0)],
      ["Шум измерений (±°C)", format(lastInputs.noise,2)],
      [],
      ["Результаты опыта"],
      ["T1'' (°C)", format(lastResult.meas.ThOut_m,2)],
      ["T2'' (°C)", format(lastResult.meas.TcOut_m,2)],
      ["Qх (Вт)", formatW(lastResult.Qcold)],
      ["Qг (Вт)", formatW(lastResult.Qhot)],
      ["Эффективность ε", format(lastResult.eps,3)],
      ["Δt_lm (°C)", format(lastResult.LMTD,2)],
      ["F (м²)", format(F,5)],
      ["kрасч (Вт/(м²·К))", format(lastResult.kCalc,0)],
      [],
      ["Журнал экспериментов"],
      ["№","Дата/время","Режим","T1'","T2'","Gг","Gх","ε","Qх","kрасч"],
      ...journal.map((e, idx)=>[
        idx+1,
        e.time,
        modeLabel(e.mode),
        format(e.inputs.ThIn,1),
        format(e.inputs.TcIn,1),
        format(e.inputs.Gh,2),
        format(e.inputs.Gc,2),
        format(e.result.eps,3),
        formatW(e.result.Qcold),
        format(e.result.kCalc,0),
      ]),
    ];

    const csv = "\uFEFF" + rows.map((row)=>row.map((v)=>escapeCsv(v ?? "")).join(";")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "heat-exchanger-lab-report.csv";
    link.click();
    URL.revokeObjectURL(link.href);
  }

  function reset(){
    ui.ThIn.value = "55";
    ui.TcIn.value = "20";
    ui.Gh.value = "2.0";
    ui.Gc.value = "2.7";
    ui.U.value = "650";
    ui.noise.value = "0.20";
    ui.seed.value = "12345";
    setMode("counter");
    recalc();
    renderJournal();
  }

  ui.btnCounter.addEventListener("click", ()=>setMode("counter"));
  ui.btnParallel.addEventListener("click", ()=>setMode("parallel"));

  [ui.ThIn, ui.TcIn, ui.Gh, ui.Gc, ui.U, ui.noise].forEach((el)=>{
    el.addEventListener("input", recalc);
  });
  ui.seed.addEventListener("change", recalc);

  ui.btnNewRun.addEventListener("click", ()=>{
    const s = parseInt(ui.seed.value || "0", 10);
    ui.seed.value = String((s + 101) % 1000000);
    recalc();
  });
  ui.btnAddToJournal.addEventListener("click", addCurrentToJournal);
  ui.btnClearJournal.addEventListener("click", clearJournal);
  ui.btnExportExcel.addEventListener("click", exportExcel);
  ui.btnReset.addEventListener("click", reset);

  buildChart();
  buildTempProfileChart();
  reset();
})();
